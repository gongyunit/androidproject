// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.news.util;

import android.util.Log;

import com.gy.news.constants.GyConstants;

public class LogUtil {
	private static boolean logable;
	private static int logLevel;
	
	public static void init(){
		/**
		 * 设置是否打印日志和日志等级
		 */
		setLogable(true);
		setLogLevel(LogPriority.VERBOSE);
	}
	
	public static enum LogPriority {
		VERBOSE, DEBUG, INFO, WARN, ERROR, ASSERT
	}
	
	public static void d(String tag,String msg){
		log(LogPriority.DEBUG, tag, msg, null);
	}
	
	public static void d(String tag,String msg,Throwable tr){
		log(LogPriority.DEBUG, tag, msg, tr);
	}
	
	public static void e(String tag,String msg){
		log(LogPriority.ERROR, tag, msg, null);
	}
	
	public static void e(String tag,String msg,Throwable tr){
		log(LogPriority.ERROR, tag, msg, tr);
	}
	
	public static void i(String msg){
		log(LogPriority.INFO, GyConstants.TAG, msg, null);
	}
	
	public static void i(String tag,String msg,Throwable tr){
		log(LogPriority.INFO, tag, msg, tr);
	}
	
	public static void v(String tag,String msg){
		log(LogPriority.VERBOSE, tag, msg, null);
	}
	public static void v(String tag,String msg,Throwable tr){
		log(LogPriority.VERBOSE, tag, msg, tr);
	}
	
	public static void w(String tag,String msg){
		log(LogPriority.WARN, tag, msg, null);
	}
	
	public static void w(String tag,String msg,Throwable tr){
		log(LogPriority.WARN, tag, msg, tr);
	}
	
	
	/**
	 * 获取是否可打印日志
	 * 
	 * @return
	 */
	public static boolean isLogable() {
		return logable;
	}

	/**
	 * 设置是否打印日志
	 * 
	 * @param logable
	 */
	public static void setLogable(boolean logable) {
		LogUtil.logable = logable;
	}

	/**
	 * 设置日志等级
	 * 
	 * @param level
	 */
	public static void setLogLevel(LogPriority level) {
		LogUtil.logLevel = level.ordinal();
	}


	private static void log(LogPriority priority,String tag,String msg,Throwable tr){
		int level = priority.ordinal();
		if (logable && logLevel <= level) {
			if(tr != null){
				msg = msg + "\n" + Log.getStackTraceString(tr);
			}
			Log.println(level + 2, tag, msg);
		}
	}
}