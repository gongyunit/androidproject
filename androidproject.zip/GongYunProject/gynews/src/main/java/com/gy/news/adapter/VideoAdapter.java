// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.news.adapter;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.gy.news.R;
import com.gy.news.model.News;

import java.util.List;


/**
 * Created by Administrator on 2017/2/8 0008.
 */

public class VideoAdapter extends BaseQuickAdapter<News> {
    public VideoAdapter(List<News> data) {
        super(R.layout.item_video_list, data);
    }

    @Override
    protected void convert(BaseViewHolder baseViewHolder, final News news) {
        baseViewHolder
//                .setText(R.id.tvDuration, news.video_duration_str)
                .setText(R.id.tvFrom, news.source)
                .setText(R.id.tvCommentCount, news.comments_count + "")
                .setText(R.id.text_video_details, news.title)
                .setText(R.id.tvDuration, news.video_duration_str);
    }

    private void setPlayer(News news) {
    }
}
