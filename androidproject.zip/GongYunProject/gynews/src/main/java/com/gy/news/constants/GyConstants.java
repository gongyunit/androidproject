// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.news.constants;

import android.app.Application;

/**
 * 常量存放类
 */
public class GyConstants {
    public static Application appContext;
    public static String TAG = "gynews";
    public static String DATA = "data";
    public static String DATA_SELECTED = "dataSelected";
    public static String DATA_UNSELECTED = "dataUnselected";
    public static String ARTICLE_GENRE_VIDEO = "video";
    public static String ARTICLE_GENRE_ARTICLE = "article";
    public static String ARTICLE_GENRE_ARTICLE_SINGLE_PIC = "article_single_pic";
    public static String ARTICLE_GENRE_ARTICLE_THREE_PIC = "article_three_pic";
    public static String ARTICLE_GENRE_ARTICLE_BIG_PIC = "big_pic";
    public static String URL = "url";
    public static String GROUP_ID = "groupId";
    public static String ITEM_ID = "itemId";
    public static String SP_THEME = "theme";

    public static String TITLE_SELECTED = "explore_title_selected";
    public static String TITLE_UNSELECTED = "explore_title_unselected";

    public static String VIDEO_TITLE_SELECTED = "video_explore_title_selected";
    public static String VIDEO_TITLE_UNSELECTED = "video_explore_title_unselected";

    public static int THEME_LIGHT = 1;
    public static int THEME_NIGHT = 2;
}
