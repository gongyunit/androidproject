// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.news.activity;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.RelativeLayout;
import android.widget.VideoView;

import com.gy.news.R;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by Administrator on 2016/11/24 0024.
 */

public class VideoDetailActivity extends Activity {
    @BindView(R.id.videoPlayer)
    VideoView mVideoView;

    @BindView(R.id.full_screeen)
    RelativeLayout fullScreenImg;

    @BindView(R.id.video_others)
    LinearLayout videoOthers;

    private int HANDLER_DISMISS_FULL_SCREEN_ICON = 0;
    private long dismissFullScreenImg = 3000;

    Handler mHandler = new Handler(){
        @Override
        public void dispatchMessage(Message msg) {
            super.dispatchMessage(msg);
            if (msg.what == HANDLER_DISMISS_FULL_SCREEN_ICON){
                fullScreenImg.setVisibility(View.INVISIBLE);
            }
        }
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.activity_video_detail);
        ButterKnife.bind(this);
        MediaController controller = new MediaController(this);
        controller.setPadding(0,100,0,0);

        Uri uri = Uri.parse("http://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4");
        mVideoView.setMediaController(controller);
        mVideoView.setVideoURI(uri);
        mVideoView.start();

        //视频准备好后的监听
        mVideoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mediaPlayer) {
                mVideoView.setBackgroundResource(0);
                fullScreenImg.setVisibility(View.VISIBLE);
                mHandler.sendEmptyMessageDelayed(HANDLER_DISMISS_FULL_SCREEN_ICON,dismissFullScreenImg);
            }
        });

        //视频播放完成的监听
        mVideoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mediaPlayer) {
                mVideoView.start();
            }
        });

        //播放器点击监听
        mVideoView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (motionEvent.getAction() == MotionEvent.ACTION_DOWN){
                    if (fullScreenImg.getVisibility() == View.VISIBLE){
                        fullScreenImg.setVisibility(View.INVISIBLE);
                    } else {
                        fullScreenImg.setVisibility(View.VISIBLE);
                        mHandler.sendEmptyMessageDelayed(HANDLER_DISMISS_FULL_SCREEN_ICON,dismissFullScreenImg);
                    }
                }
                return false;
            }
        });

        fullScreenImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (videoOthers.getVisibility() == View.VISIBLE){
                    videoOthers.clearAnimation();
                    videoOthers.setVisibility(View.GONE);
                } else {
                    videoOthers.clearAnimation();
                    videoOthers.setVisibility(View.VISIBLE);
                }
                setOrientation();
            }
        });
    }

    /**
     * 设置全屏与半屏的切换
     */
    private void setOrientation() {
        Configuration mConfiguration = getResources().getConfiguration(); //获取设置的配置信息
        int ori = mConfiguration.orientation; //获取屏幕方向
        if (ori == ActivityInfo.SCREEN_ORIENTATION_PORTRAIT) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
            fullscreen(true);
        } else {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            fullscreen(false);
        }
    }

    private void fullscreen(boolean enable) {
        if (enable) { //显示状态栏
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.flags |= WindowManager.LayoutParams.FLAG_FULLSCREEN;
            getWindow().setAttributes(lp);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        } else { //隐藏状态栏
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.flags &= (~WindowManager.LayoutParams.FLAG_FULLSCREEN);
            getWindow().setAttributes(lp);
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        }
    }

    @Override
    public void onBackPressed() {
        Configuration mConfiguration = getResources().getConfiguration(); //获取设置的配置信息
        int ori = mConfiguration.orientation; //获取屏幕方向
        if (ori == ActivityInfo.SCREEN_ORIENTATION_PORTRAIT) {
            finish();
        } else {
            videoOthers.clearAnimation();
            videoOthers.setVisibility(View.VISIBLE);
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            fullscreen(false);
        }
    }
}
