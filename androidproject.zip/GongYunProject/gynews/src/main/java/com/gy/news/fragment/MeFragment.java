// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.news.fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TextView;

import com.gy.news.R;
import com.gy.news.adapter.DragGridViewAdapter;
import com.gy.news.draggridview.DragCallback;
import com.gy.news.draggridview.DragGridView;
import com.gy.news.util.AssistUtils;
import com.gy.news.util.LogUtil;
import com.gy.news.view.HeaderZoomLayout;

import java.util.ArrayList;
import java.util.List;

public class MeFragment extends BaseFragment {
    private TextView txt_my_page_message;
    private ImageView ivBg;
    private HeaderZoomLayout zommLayout;
    private DragGridView gv_drag_main;
    private DragGridViewAdapter dragGridViewAdapter;

    private List<Integer> iconList = new ArrayList<Integer>();
    private List<String> nameList = new ArrayList<String>();

    @Override
    protected View loadViewLayout(LayoutInflater inflater, ViewGroup container) {
        return inflater.inflate(R.layout.fragment_me, null);
    }

    @Override
    protected void bindViews(View view) {
        zommLayout = get(R.id.zommLayout);
        gv_drag_main = get(R.id.gv_drag_main);
    }

    @Override
    protected void initData() {
        iconList.add(R.drawable.main_setting_clear_cache);
        iconList.add(R.drawable.main_setting_feedback);
        iconList.add(R.drawable.main_setting_new_user);
        iconList.add(R.drawable.main_setting_recive_msg);
        iconList.add(R.drawable.main_setting_system_update);
        iconList.add(R.drawable.main_ssetting_about);
        nameList.add("清除缓存");
        nameList.add("信息反馈");
        nameList.add("新手导览");
        nameList.add("消息推送");
        nameList.add("系统设置");
        nameList.add("关于我们");
        initDragGridView();
    }

    @Override
    protected void setListener() {
    }


    private void initDragGridView() {
        dragGridViewAdapter = new DragGridViewAdapter(getActivity(), iconList, nameList);
        gv_drag_main.setAdapter(dragGridViewAdapter);

        gv_drag_main.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                gv_drag_main.startDrag(position);
                return true;
            }
        });

        gv_drag_main.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                try {
                    gv_drag_main.clicked();
                    //防止快速多次点击
                    if (AssistUtils.isFastClick()) {
                        return;
                    }
                    switch (dragGridViewAdapter.iconList.get(position)) {
                        case R.drawable.logo:
                            LogUtil.i("click ============ ");
                            break;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        gv_drag_main.setDragCallback(new DragCallback() {
            @Override
            public void startDrag(int position) {
            }

            @Override
            public void endDrag(int position) {
               LogUtil.i("endDrag");
            }
        });
    }
}
