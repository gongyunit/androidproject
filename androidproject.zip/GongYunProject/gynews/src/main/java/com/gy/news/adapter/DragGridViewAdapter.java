// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.news.adapter;


import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.gy.news.R;
import com.gy.news.draggridview.DragAdapterInterface;

import java.util.List;

/**
 * Created by Wangyanfei on 2016/6/21.
 */
public class DragGridViewAdapter extends BaseAdapter implements DragAdapterInterface {

    public List<Integer> iconList;
    public List<String> nameList;
    public Context context;

    public DragGridViewAdapter(Context context, List<Integer> iconList, List<String> nameList) {
        this.iconList = iconList;
        this.nameList = nameList;
        this.context = context;
    }

    @Override
    public int getCount() {
        return iconList.size();
    }

    @Override
    public Object getItem(int position) {
        return iconList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if(convertView==null)
        {
            holder=new ViewHolder();
            convertView= View.inflate(context, R.layout.item_draggridview,null);
            holder.iconImage = (ImageView) convertView.findViewById(R.id.icon_img);
            holder.tvName = (TextView) convertView.findViewById(R.id.name_tv);
            convertView.setTag(holder);
        }
        else
        {
            holder= (ViewHolder) convertView.getTag();
        }

        holder.iconImage.setImageResource(iconList.get(position));
        holder.tvName.setText(nameList.get(position));
        return convertView;
    }

    static class ViewHolder {
        public ImageView iconImage;
        public TextView tvName;
    }

    @Override
    public void reOrder(int startPosition, int endPosition) {
        if (endPosition < nameList.size()) {
            Object object = iconList.remove(startPosition);
            Object object2 = nameList.remove(startPosition);
            iconList.add(endPosition, (Integer) object);
            nameList.add(endPosition, (String) object2);
            notifyDataSetChanged();
        }
    }


}
