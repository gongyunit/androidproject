// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.news;

import android.app.Application;

import com.gy.news.constants.GyConstants;
import com.gy.news.util.LogUtil;
import com.gy.news.util.SharedPreferenceUtil;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;

/**
 * Application 基类
 */
public class BaseApplication extends Application {
    //private UserInfo userInfo;
    private static BaseApplication instance;

    @Override
    public void onCreate() {
        super.onCreate();
        GyConstants.appContext = this;
        instance = this;
        LogUtil.init();
        SharedPreferenceUtil.init(this, "gongyun");
        initImageLoader();
    }

    private void initImageLoader() {
        ImageLoaderConfiguration.Builder config = new ImageLoaderConfiguration.Builder(
                instance);
        config.memoryCacheExtraOptions(480, 800);
        config.diskCacheExtraOptions(480, 800, null);
        config.diskCacheSize(100 * 1024 * 1024); // 100 MiB
        if (BuildConfig.DEBUG) {
            config.writeDebugLogs(); // Remove for release app
        }
        ImageLoader.getInstance().init(config.build());
    }

    //    public UserInfo getUserInfo() {
//        return userInfo;
//    }
//
//    public void setUserInfo(UserInfo userInfo) {
//        this.userInfo = userInfo;
//    }
    public static BaseApplication getInstance() {
        return instance;
    }
}
