// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.news.adapter;

import android.widget.ImageView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.gy.news.R;
import com.gy.news.constants.GyConstants;
import com.gy.news.model.News;
import com.gy.news.util.DateUtils;

import java.util.List;

public class NewsAdapter extends BaseQuickAdapter<News> {
    public NewsAdapter(List<News> data) {
        super(R.layout.item_news, data);
    }

    @Override
    protected void convert(BaseViewHolder baseViewHolder, News news) {
        setGone(baseViewHolder);
        if (news.article_genre.equals(GyConstants.ARTICLE_GENRE_ARTICLE_SINGLE_PIC)) {
            //单图片右侧小图类型
            ((ImageView) baseViewHolder.getView(R.id.ivRightImg1)).setImageResource(R.drawable.news2);
            baseViewHolder.setVisible(R.id.rlRightImg, true)
                    .setVisible(R.id.viewFill, true);

        } else if (news.article_genre.equals(GyConstants.ARTICLE_GENRE_ARTICLE_BIG_PIC)) {
            //单图片下方大图类型
            ((ImageView) baseViewHolder.getView(R.id.ivBigImg)).setImageResource(R.drawable.news4);
            baseViewHolder.setVisible(R.id.rlBigImg, true)
                    .setText(R.id.tvImgCount, 1 + "图");

        } else if (news.article_genre.equals(GyConstants.ARTICLE_GENRE_VIDEO)) {
            //视频类型
            ((ImageView) baseViewHolder.getView(R.id.ivRightImg1)).setImageResource(R.drawable.news5);
            baseViewHolder.setVisible(R.id.rlRightImg, true)
                    .setVisible(R.id.viewFill, true)
                    .setVisible(R.id.llVideo, true).setText(R.id.tvDuration, news.video_duration_str);
        } else if (news.article_genre.equals(GyConstants.ARTICLE_GENRE_ARTICLE_THREE_PIC)){
            //三张图片下方类型
            baseViewHolder.setVisible(R.id.llCenterImg, true);

            ((ImageView) baseViewHolder.getView(R.id.ivCenterImg1)).setImageResource(R.drawable.news31);
            ((ImageView) baseViewHolder.getView(R.id.ivCenterImg2)).setImageResource(R.drawable.news32);
            ((ImageView) baseViewHolder.getView(R.id.ivCenterImg3)).setImageResource(R.drawable.news33);
        }
        baseViewHolder.setText(R.id.tvTitle, news.title)
                .setText(R.id.tvAuthorName, news.source)
                .setText(R.id.tvCommentCount, news.comments_count + "评论")
                .setText(R.id.tvTime, DateUtils.getShortTime(news.time * 1000));;
    }

    private void setGone(BaseViewHolder baseViewHolder) {
        baseViewHolder.setVisible(R.id.viewFill, false)
                .setVisible(R.id.llCenterImg, false)
                .setVisible(R.id.rlBigImg, false)
                .setVisible(R.id.llVideo, false)
                .setVisible(R.id.rlRightImg, false);

    }
}
