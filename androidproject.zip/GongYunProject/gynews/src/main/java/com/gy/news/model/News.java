// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.news.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class News implements Serializable{
    @SerializedName("abstract")
    /**
     * 新闻标题
     */
    public String title;
    /**
     * 新闻来源
     */
    public String source;
    /**
     * 发生时间
     */
    public Long time;
    /**
     * 评论数
     */
    public int comments_count;
    /**
     * 新闻题材类型 纯文本 图文 或视频新闻
     */
    public String article_genre;
    /**
     * 视频时长的描述
     */
    public String video_duration_str;
}
