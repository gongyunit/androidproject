// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.news.draggridview;

/**
 * Created by Wangyanfei on 2016/6/17.
 */
public interface DragAdapterInterface {
    void reOrder(int startPosition, int endPosition);
}
