// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
package com.gy.news.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.gy.news.R;
import com.gy.news.activity.NewsDetailActivity;
import com.gy.news.activity.VideoDetailActivity;
import com.gy.news.adapter.VideoAdapter;
import com.gy.news.constants.GyConstants;
import com.gy.news.model.News;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

import static com.gy.news.constants.GyConstants.DATA;

public class VideoListFragment extends BaseFragment {

    @BindView(R.id.recyclerView)
    public RecyclerView recyclerView;
    @BindView(R.id.srl)
    SwipeRefreshLayout srl;
    private String mTitleCode = "";
    protected List<News> mDatas = new ArrayList<>();
    protected BaseQuickAdapter mAdapter;
    @Override
    protected View loadViewLayout(LayoutInflater inflater, ViewGroup container) {
        View v = inflater.inflate(R.layout.layout_recyclerview, null);
        ButterKnife.bind(this, v);
        return v;
    }

    public static VideoListFragment newInstance(String code) {
        VideoListFragment fragment = new VideoListFragment();
        Bundle bundle = new Bundle();
        bundle.putString(DATA, code);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    protected void bindViews(View view) {
    }

    @Override
    protected void initData() {
        initCommonRecyclerView(createAdapter(), null);
        mTitleCode = getArguments().getString(DATA);
    }

    protected BaseQuickAdapter createAdapter() {
        return mAdapter = new VideoAdapter(mDatas);
    }

    @Override
    protected void lazyLoad() {
        super.lazyLoad();
        if (TextUtils.isEmpty(mTitleCode))
            mTitleCode = getArguments().getString(DATA);
        getData();
    }

    private void getData() {
        News news5 = new News();
        news5.article_genre = GyConstants.ARTICLE_GENRE_VIDEO;
        news5.time = 1498515986l;
        news5.source = "工云头条";
        news5.title = "东方卫视笑声传奇 高晓攀";
        news5.comments_count = 1073;
        news5.video_duration_str = "03:50";


        News news4 = new News();
        news4.article_genre = GyConstants.ARTICLE_GENRE_VIDEO;
        news4.time = 1498515986l;
        news4.source = "工云头条";
        news4.title = "喜剧人的风采 高晓攀 于先超";
        news4.comments_count = 307;
        news4.video_duration_str = "04:59";

        News news3 = new News();
        news3.article_genre = GyConstants.ARTICLE_GENRE_VIDEO;
        news3.time = 1498515986l;
        news3.source = "工云头条";
        news3.title = "工云头条 IT技术全面覆盖 请关注微信公众号 “工云IT技术”";
        news3.comments_count = 30573;
        news3.video_duration_str = "06:11";

        for (int i = 0 ; i < 2 ; i ++ ){
            mDatas.add(news5);
            mDatas.add(news4);
            mDatas.add(news3);
        }
        mAdapter.notifyItemRangeChanged(0, mDatas.size());
        /**
         * 此处对于下拉刷新 获取到数据以后停止下拉刷新
         */
        srl.setRefreshing(false);
    }

    @Override
    protected void setListener() {
        /**
         * 设置下拉刷新
         */
        srl.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                getData();
            }
        });
        mAdapter.setOnRecyclerViewItemClickListener(new BaseQuickAdapter.OnRecyclerViewItemClickListener() {
            @Override
            public void onItemClick(View view, int i) {
                News news = mDatas.get(i);
                if(news.article_genre.equals(GyConstants.ARTICLE_GENRE_VIDEO)){
                    //视频类型
                    Intent intent = new Intent(getActivity(), VideoDetailActivity.class);
                    startActivity(intent);
                } else {
                    Intent intent = new Intent(getActivity(), NewsDetailActivity.class);
                    startActivity(intent);
                }
            }
        });
    }
}
